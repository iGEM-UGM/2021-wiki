# Auviola: Dry Lab Models | [UGM_Indonesia 2021](https://2021.igem.org/Team:UGM_Indonesia/Model#) 
This folder contains the dry lab work of UGM_Indonesia 2021 team.

## Directories & Files
* maps : contains the escher map for C. violaceum metabolic model in this project.
* models: contains the C. violaceum SBML file, made compatible with CobraPy / Cameo. The original model can be found in [0] and the map was a gift from the author.
* notebooks : contains the jupyter notebook file that used in this project
* results : contains some map output in html from gene knockout prediction task
* tables : contains the tables of some reactions data in csv file which related to curated process

[0] Banerjee, D., Raghunathan, A., 2019, Constraints-based analysis identifies NAD+ recycling through metabolic reprogramming in antibiotic resistant Chromobacterium violaceum, PLOS ONE, vol. 14, no. 1, pp. e0210008.


## Usage
You can run the notebooks with conda. All dependencies can be found in the environment file (.yml)
`conda install conda env create -f environment.yml`
`conda activate ....`
