# Auviola: Dry Lab Models | [UGM_Indonesia 2021](https://2021.igem.org/Team:UGM_Indonesia/Model#) 
This folder contains the dry lab work of UGM_Indonesia 2021 team.


## Files
* iGEM_Kinetic_Model.ipynb contains modelling of HCN production, HCN degradation, and L-arabinose conversion to L-ribulose. 
* Gold_cyanidation.ipynb contains gold and cyanide interaction in gold cyanidation process


## Usage
You can run the notebooks with conda. All dependencies can be found in the environment file (.yml)
`conda install conda env create -f environment.yml`
`conda activate ....`

Or you can install Anaconda on Windows or macOS, then run both file on Jupyter Notebook or Jupyter Lab

For iGEM_Kinetic_Model.ipynb, you need to install Tellurium package before running each of its command
Install Tellurium via pip:

pip install tellurium